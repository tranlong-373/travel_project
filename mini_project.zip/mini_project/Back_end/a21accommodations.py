from fastapi import APIRouter, HTTPException
from a02connection import get_connection

router = APIRouter(prefix="/accommodations", tags=["Accommodations"])


@router.get("")
def getaccommodations():
    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            select
                a.AccommodationID,
                a.AccommodationName,
                c.CityName,
                d.DistrictName,
                t.TypeName,
                a.PricePerNight,
                a.Rating,
                a.MaxPeople,
                a.Latitude,
                a.Longitude,
                a.MainImageURL
            from stay.Accommodations a
            join stay.Cities c on a.CityID = c.CityID
            left join stay.Districts d on a.DistrictID = d.DistrictID
            join stay.AccommodationTypes t on a.AccommodationTypeID = t.AccommodationTypeID
            where a.IsActive = 1
            order by a.AccommodationID
        """)

        rows = cursor.fetchall()

        result = []
        for row in rows:
            result.append({
                "AccommodationID": row.AccommodationID,
                "AccommodationName": row.AccommodationName,
                "CityName": row.CityName,
                "DistrictName": row.DistrictName,
                "TypeName": row.TypeName,
                "PricePerNight": float(row.PricePerNight),
                "Rating": float(row.Rating),
                "MaxPeople": row.MaxPeople,
                "Latitude": float(row.Latitude) if row.Latitude is not None else None,
                "Longitude": float(row.Longitude) if row.Longitude is not None else None,
                "MainImageURL": row.MainImageURL
            })

        cursor.close()
        conn.close()

        return {
            "count": len(result),
            "results": result
        }

    except Exception as e:
        return {
            "message": "Lay danh sach cho o that bai",
            "error": str(e)
        }


@router.get("/{accommodationid}")
def getaccommodationdetail(accommodationid: int):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            select
                a.AccommodationID,
                a.AccommodationName,
                a.AddressLine,
                a.Description,
                c.CityName,
                d.DistrictName,
                t.TypeName,
                a.PricePerNight,
                a.Rating,
                a.ReviewCount,
                a.MaxPeople,
                a.Latitude,
                a.Longitude,
                a.MainImageURL,
                a.PhoneNumber,
                a.WebsiteURL,
                a.CheckInTime,
                a.CheckOutTime
            from stay.Accommodations a
            join stay.Cities c on a.CityID = c.CityID
            left join stay.Districts d on a.DistrictID = d.DistrictID
            join stay.AccommodationTypes t on a.AccommodationTypeID = t.AccommodationTypeID
            where a.AccommodationID = ?
              and a.IsActive = 1
        """, accommodationid)

        row = cursor.fetchone()

        if not row:
            cursor.close()
            conn.close()
            raise HTTPException(status_code=404, detail="Accommodation not found")

        detail = {
            "AccommodationID": row.AccommodationID,
            "AccommodationName": row.AccommodationName,
            "AddressLine": row.AddressLine,
            "Description": row.Description,
            "CityName": row.CityName,
            "DistrictName": row.DistrictName,
            "TypeName": row.TypeName,
            "PricePerNight": float(row.PricePerNight),
            "Rating": float(row.Rating),
            "ReviewCount": row.ReviewCount,
            "MaxPeople": row.MaxPeople,
            "Latitude": float(row.Latitude) if row.Latitude is not None else None,
            "Longitude": float(row.Longitude) if row.Longitude is not None else None,
            "MainImageURL": row.MainImageURL,
            "PhoneNumber": row.PhoneNumber,
            "WebsiteURL": row.WebsiteURL,
            "CheckInTime": str(row.CheckInTime) if row.CheckInTime is not None else None,
            "CheckOutTime": str(row.CheckOutTime) if row.CheckOutTime is not None else None
        }

        cursor.execute("""
            select
                ImageURL,
                ImageCaption,
                DisplayOrder,
                IsMainImage
            from stay.AccommodationImages
            where AccommodationID = ?
            order by DisplayOrder asc
        """, accommodationid)

        images = []
        for r in cursor.fetchall():
            images.append({
                "ImageURL": r.ImageURL,
                "ImageCaption": r.ImageCaption,
                "DisplayOrder": r.DisplayOrder,
                "IsMainImage": bool(r.IsMainImage)
            })

        cursor.execute("""
            select
                m.AmenityName
            from stay.AccommodationAmenities aa
            join stay.Amenities m on aa.AmenityID = m.AmenityID
            where aa.AccommodationID = ?
            order by m.AmenityName
        """, accommodationid)

        amenities = [r.AmenityName for r in cursor.fetchall()]

        cursor.execute("""
            select
                t.TagName
            from stay.AccommodationTags atg
            join stay.Tags t on atg.TagID = t.TagID
            where atg.AccommodationID = ?
            order by t.TagName
        """, accommodationid)

        tags = [r.TagName for r in cursor.fetchall()]

        cursor.execute("""
            select
                ReviewerName,
                Rating,
                ReviewTitle,
                ReviewText,
                ReviewDate
            from stay.Reviews
            where AccommodationID = ?
              and IsApproved = 1
            order by ReviewDate desc
        """, accommodationid)

        reviews = []
        for r in cursor.fetchall():
            reviews.append({
                "ReviewerName": r.ReviewerName,
                "Rating": float(r.Rating),
                "ReviewTitle": r.ReviewTitle,
                "ReviewText": r.ReviewText,
                "ReviewDate": str(r.ReviewDate)
            })

        cursor.close()
        conn.close()

        detail["Images"] = images
        detail["Amenities"] = amenities
        detail["Tags"] = tags
        detail["Reviews"] = reviews

        return detail

    except HTTPException:
        raise
    except Exception as e:
        return {
            "message": "Lay chi tiet cho o that bai",
            "error": str(e)
        }