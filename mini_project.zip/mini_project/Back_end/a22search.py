from typing import Optional
from fastapi import APIRouter
from pydantic import BaseModel
from a02connection import get_connection

router = APIRouter(prefix="/search", tags=["Search"])


class SearchRequest(BaseModel):
    city: Optional[str] = None
    district: Optional[str] = None
    typename: Optional[str] = None
    budgetmin: Optional[float] = None
    budgetmax: Optional[float] = None
    numberofpeople: Optional[int] = None


@router.post("")
def searchaccommodations(request: SearchRequest):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        query = """
            select
                a.AccommodationID,
                a.AccommodationName,
                c.CityName,
                d.DistrictName,
                t.TypeName,
                a.PricePerNight,
                a.Rating,
                a.MaxPeople,
                a.Latitude,
                a.Longitude,
                a.MainImageURL
            from stay.Accommodations a
            join stay.Cities c on a.CityID = c.CityID
            left join stay.Districts d on a.DistrictID = d.DistrictID
            join stay.AccommodationTypes t on a.AccommodationTypeID = t.AccommodationTypeID
            where a.IsActive = 1
        """

        params = []

        if request.city:
            query += " and c.CityName = ?"
            params.append(request.city)

        if request.district:
            query += " and d.DistrictName = ?"
            params.append(request.district)

        if request.typename:
            query += " and t.TypeName = ?"
            params.append(request.typename)

        if request.budgetmin is not None:
            query += " and a.PricePerNight >= ?"
            params.append(request.budgetmin)

        if request.budgetmax is not None:
            query += " and a.PricePerNight <= ?"
            params.append(request.budgetmax)

        if request.numberofpeople is not None:
            query += " and a.MaxPeople >= ?"
            params.append(request.numberofpeople)

        query += " order by a.Rating desc, a.PricePerNight asc"

        cursor.execute(query, params)
        rows = cursor.fetchall()

        result = []
        for row in rows:
            result.append({
                "AccommodationID": row.AccommodationID,
                "AccommodationName": row.AccommodationName,
                "CityName": row.CityName,
                "DistrictName": row.DistrictName,
                "TypeName": row.TypeName,
                "PricePerNight": float(row.PricePerNight),
                "Rating": float(row.Rating),
                "MaxPeople": row.MaxPeople,
                "Latitude": float(row.Latitude) if row.Latitude is not None else None,
                "Longitude": float(row.Longitude) if row.Longitude is not None else None,
                "MainImageURL": row.MainImageURL
            })

        cursor.close()
        conn.close()

        return {
            "message": "Tim kiem thanh cong",
            "count": len(result),
            "results": result
        }

    except Exception as e:
        return {
            "message": "Tim kiem that bai",
            "error": str(e)
        }