from fastapi import FastAPI
from a02connection import get_connection
from a11health import router as healthrouter
from a12metadata import router as metadatarouter
from a21accommodations import router as accommodationsrouter
from a22search import router as searchrouter
from a31recommend import router as recommendrouter
from a32chatbot import router as chatbotrouter

app = FastAPI(
    title="Smart Stay Travel API",
    version="1.0.0",
    description="Backend cho web lưu tru thong minh"
)

app.include_router(healthrouter)
app.include_router(metadatarouter)
app.include_router(accommodationsrouter)
app.include_router(searchrouter)
app.include_router(recommendrouter)
app.include_router(chatbotrouter)

@app.get("/")
def root():
    return {
        "message": "Smart Stay Travel backend is running"
    }


@app.get("/test-db")
def test_db():
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT DB_NAME()")
        row = cursor.fetchone()

        cursor.close()
        conn.close()

        return {
            "message": "Ket noi database thanh cong",
            "database_name": row[0]
        }
    except Exception as e:
        return {
            "message": "Ket noi database that bai",
            "error": str(e)
        }