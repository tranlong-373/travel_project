from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional
from a02connection import get_connection

router = APIRouter(prefix="/chatbot", tags=["Chatbot"])


class ChatbotRequest(BaseModel):
    message: str


def extractfilters(message: str):
    text = message.lower()

    city = None
    district = None
    typename = None
    budgetmax = None
    numberofpeople = None

    if "đà lạt" in text:
        city = "Đà Lạt"
    elif "đà nẵng" in text:
        city = "Đà Nẵng"
    elif "hồ chí minh" in text or "sài gòn" in text:
        city = "Hồ Chí Minh"

    if "phường 1" in text:
        district = "Phường 1"
    elif "phường 10" in text:
        district = "Phường 10"
    elif "quận 1" in text:
        district = "Quận 1"
    elif "quận 7" in text:
        district = "Quận 7"
    elif "hải châu" in text:
        district = "Hải Châu"
    elif "sơn trà" in text:
        district = "Sơn Trà"

    if "homestay" in text:
        typename = "Homestay"
    elif "hotel" in text or "khách sạn" in text:
        typename = "Hotel"
    elif "resort" in text:
        typename = "Resort"
    elif "hostel" in text:
        typename = "Hostel"
    elif "apartment" in text or "căn hộ" in text:
        typename = "Apartment"

    if "2 người" in text:
        numberofpeople = 2
    elif "3 người" in text:
        numberofpeople = 3
    elif "4 người" in text:
        numberofpeople = 4
    elif "5 người" in text:
        numberofpeople = 5

    numbers = []
    current = ""
    for ch in text:
        if ch.isdigit():
            current += ch
        else:
            if current:
                numbers.append(int(current))
                current = ""
    if current:
        numbers.append(int(current))

    for n in numbers:
        if n >= 100000:
            budgetmax = float(n)
            break

    return {
        "city": city,
        "district": district,
        "typename": typename,
        "budgetmax": budgetmax,
        "numberofpeople": numberofpeople
    }


def calculatechatbotscore(item: dict, filters: dict):
    score = 0.0
    reasons = []

    if filters["city"] and item["CityName"] == filters["city"]:
        score += 30
        reasons.append("phù hợp thành phố")

    if filters["district"] and item["DistrictName"] == filters["district"]:
        score += 10
        reasons.append("đúng khu vực")

    if filters["typename"] and item["TypeName"] == filters["typename"]:
        score += 15
        reasons.append("đúng loại chỗ ở")

    if filters["budgetmax"] is not None and item["PricePerNight"] <= filters["budgetmax"]:
        score += 25
        reasons.append("phù hợp ngân sách")

    if filters["numberofpeople"] is not None and item["MaxPeople"] >= filters["numberofpeople"]:
        score += 10
        reasons.append("đủ số người")

    ratingscore = (item["Rating"] / 5.0) * 20
    score += ratingscore

    if item["Rating"] >= 4:
        reasons.append("rating cao")

    return round(score, 2), reasons


@router.post("")
def chatbotreply(request: ChatbotRequest):
    try:
        filters = extractfilters(request.message)

        conn = get_connection()
        cursor = conn.cursor()

        query = """
            select
                a.AccommodationID,
                a.AccommodationName,
                c.CityName,
                d.DistrictName,
                t.TypeName,
                a.PricePerNight,
                a.Rating,
                a.MaxPeople,
                a.MainImageURL
            from stay.Accommodations a
            join stay.Cities c on a.CityID = c.CityID
            left join stay.Districts d on a.DistrictID = d.DistrictID
            join stay.AccommodationTypes t on a.AccommodationTypeID = t.AccommodationTypeID
            where a.IsActive = 1
        """

        params = []

        if filters["city"]:
            query += " and c.CityName = ?"
            params.append(filters["city"])

        if filters["district"]:
            query += " and d.DistrictName = ?"
            params.append(filters["district"])

        if filters["typename"]:
            query += " and t.TypeName = ?"
            params.append(filters["typename"])

        if filters["budgetmax"] is not None:
            query += " and a.PricePerNight <= ?"
            params.append(filters["budgetmax"])

        if filters["numberofpeople"] is not None:
            query += " and a.MaxPeople >= ?"
            params.append(filters["numberofpeople"])

        cursor.execute(query, params)
        rows = cursor.fetchall()

        results = []
        for row in rows:
            item = {
                "AccommodationID": row.AccommodationID,
                "AccommodationName": row.AccommodationName,
                "CityName": row.CityName,
                "DistrictName": row.DistrictName,
                "TypeName": row.TypeName,
                "PricePerNight": float(row.PricePerNight),
                "Rating": float(row.Rating),
                "MaxPeople": row.MaxPeople,
                "MainImageURL": row.MainImageURL
            }

            score, reasons = calculatechatbotscore(item, filters)
            item["RecommendationScore"] = score
            item["Reasons"] = reasons

            results.append(item)

        results.sort(key=lambda x: x["RecommendationScore"], reverse=True)

        cursor.close()
        conn.close()

        if len(results) == 0:
            return {
                "reply": "Mình chưa tìm thấy chỗ ở phù hợp với yêu cầu hiện tại.",
                "filters": filters,
                "count": 0,
                "results": []
            }

        top = results[0]
        reasontext = ", ".join(top["Reasons"]) if len(top["Reasons"]) > 0 else "phù hợp nhu cầu của bạn"

        reply = (
            f"Mình gợi ý {top['AccommodationName']} ở {top['CityName']}. "
            f"Lý do: {reasontext}. "
            f"Giá khoảng {int(top['PricePerNight'])} VND/đêm, rating {top['Rating']}."
        )

        return {
            "reply": reply,
            "filters": filters,
            "count": len(results[:3]),
            "results": results[:3]
        }

    except Exception as e:
        return {
            "reply": "Chatbot xử lý thất bại.",
            "error": str(e)
        }