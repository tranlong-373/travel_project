from typing import Optional
from fastapi import APIRouter
from pydantic import BaseModel
from a02connection import get_connection

router = APIRouter(prefix="/recommend", tags=["Recommendation"])


class RecommendRequest(BaseModel):
    city: Optional[str] = None
    district: Optional[str] = None
    typename: Optional[str] = None
    budgetmax: Optional[float] = None
    numberofpeople: Optional[int] = None


def calculaterecommendscore(item: dict, request: RecommendRequest):
    score = 0.0
    reasons = []

    if request.city and item["CityName"] == request.city:
        score += 30
        reasons.append("phù hợp thành phố")

    if request.district and item["DistrictName"] == request.district:
        score += 10
        reasons.append("đúng khu vực")

    if request.typename and item["TypeName"] == request.typename:
        score += 15
        reasons.append("đúng loại chỗ ở")

    if request.budgetmax is not None and item["PricePerNight"] <= request.budgetmax:
        score += 25
        reasons.append("phù hợp ngân sách")

    if request.numberofpeople is not None and item["MaxPeople"] >= request.numberofpeople:
        score += 10
        reasons.append("đủ số người")

    ratingscore = (item["Rating"] / 5.0) * 20
    score += ratingscore

    if item["Rating"] >= 4:
        reasons.append("rating cao")

    return round(score, 2), reasons


@router.post("")
def recommendaccommodations(request: RecommendRequest):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        query = """
            select
                a.AccommodationID,
                a.AccommodationName,
                c.CityName,
                d.DistrictName,
                t.TypeName,
                a.PricePerNight,
                a.Rating,
                a.MaxPeople,
                a.Latitude,
                a.Longitude,
                a.MainImageURL
            from stay.Accommodations a
            join stay.Cities c on a.CityID = c.CityID
            left join stay.Districts d on a.DistrictID = d.DistrictID
            join stay.AccommodationTypes t on a.AccommodationTypeID = t.AccommodationTypeID
            where a.IsActive = 1
        """

        params = []

        if request.city:
            query += " and c.CityName = ?"
            params.append(request.city)

        if request.district:
            query += " and d.DistrictName = ?"
            params.append(request.district)

        if request.typename:
            query += " and t.TypeName = ?"
            params.append(request.typename)

        if request.budgetmax is not None:
            query += " and a.PricePerNight <= ?"
            params.append(request.budgetmax)

        if request.numberofpeople is not None:
            query += " and a.MaxPeople >= ?"
            params.append(request.numberofpeople)

        cursor.execute(query, params)
        rows = cursor.fetchall()

        results = []
        for row in rows:
            item = {
                "AccommodationID": row.AccommodationID,
                "AccommodationName": row.AccommodationName,
                "CityName": row.CityName,
                "DistrictName": row.DistrictName,
                "TypeName": row.TypeName,
                "PricePerNight": float(row.PricePerNight),
                "Rating": float(row.Rating),
                "MaxPeople": row.MaxPeople,
                "Latitude": float(row.Latitude) if row.Latitude is not None else None,
                "Longitude": float(row.Longitude) if row.Longitude is not None else None,
                "MainImageURL": row.MainImageURL
            }

            score, reasons = calculaterecommendscore(item, request)
            item["RecommendationScore"] = score
            item["Reasons"] = reasons

            results.append(item)

        results.sort(key=lambda x: x["RecommendationScore"], reverse=True)

        cursor.close()
        conn.close()

        return {
            "message": "De cu thanh cong",
            "count": len(results),
            "results": results[:5]
        }

    except Exception as e:
        return {
            "message": "De cu that bai",
            "error": str(e)
        }