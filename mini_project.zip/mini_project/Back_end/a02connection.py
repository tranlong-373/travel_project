import pyodbc
from a01config import settings


def get_connection():
    conn_str = (
        f"DRIVER={{{settings.DB_DRIVER}}};"
        f"SERVER={settings.DB_SERVER};"
        f"DATABASE={settings.DB_DATABASE};"
        f"Trusted_Connection={settings.DB_TRUSTED_CONNECTION};"
    )
    return pyodbc.connect(conn_str)