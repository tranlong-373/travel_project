from fastapi import APIRouter
from a02connection import get_connection

router = APIRouter(prefix="/health", tags=["Health"])


@router.get("")
def health_check():
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT DB_NAME()")
        row = cursor.fetchone()

        cursor.close()
        conn.close()

        return {
            "status": "ok",
            "message": "Backend and database are working",
            "database_name": row[0]
        }
    except Exception as e:
        return {
            "status": "error",
            "message": "Database connection failed",
            "error": str(e)
        }