from fastapi import APIRouter
from a02connection import get_connection

router = APIRouter(prefix="/metadata", tags=["Metadata"])


@router.get("/cities")
def get_cities():
    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            select
                CityID,
                CityName
            from stay.Cities
            where IsActive = 1
            order by CityName
        """)

        rows = cursor.fetchall()

        result = []
        for row in rows:
            result.append({
                "CityID": row.CityID,
                "CityName": row.CityName
            })

        cursor.close()
        conn.close()

        return {
            "count": len(result),
            "results": result
        }

    except Exception as e:
        return {
            "message": "Lay danh sach thanh pho that bai",
            "error": str(e)
        }


@router.get("/types")
def get_accommodation_types():
    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            select
                AccommodationTypeID,
                TypeName
            from stay.AccommodationTypes
            where IsActive = 1
            order by TypeName
        """)

        rows = cursor.fetchall()

        result = []
        for row in rows:
            result.append({
                "AccommodationTypeID": row.AccommodationTypeID,
                "TypeName": row.TypeName
            })

        cursor.close()
        conn.close()

        return {
            "count": len(result),
            "results": result
        }

    except Exception as e:
        return {
            "message": "Lay danh sach loai cho o that bai",
            "error": str(e)
        }