/* =========================================================
   File: 01_create_core_tables.sql
   Folder: database/02_core_tables/
   Mục đích:
     Create core tables:
     - Accommodations
     - AccommodationImages
     - AccommodationAmenities
     - AccommodationTags
     - Reviews
========================================================= */

use SmartStayDB
go

/* ---------------------------------------------------------
   Accommodations
--------------------------------------------------------- */
create table stay.Accommodations
(
    AccommodationID int identity(1,1) not null,
    AccommodationName nvarchar(200) not null,
    AccommodationTypeID int not null,
    CityID int not null,
    DistrictID int null,
    AddressLine nvarchar(300) not null,
    Description nvarchar(1000) null,
    PricePerNight decimal(12,2) not null,
    Rating decimal(3,2) not null default 0,
    ReviewCount int not null default 0,
    MaxPeople int not null,
    Latitude decimal(9,6) null,
    Longitude decimal(9,6) null,
    MainImageURL nvarchar(500) null,
    PhoneNumber nvarchar(20) null,
    WebsiteURL nvarchar(255) null,
    CheckInTime time null,
    CheckOutTime time null,
    IsActive bit not null default 1,
    CreatedAt datetime2 not null default sysdatetime(),
    UpdatedAt datetime2 null,

    constraint PK_Accommodations primary key (AccommodationID),

    constraint FK_Accommodations_AccommodationTypes
        foreign key (AccommodationTypeID) references stay.AccommodationTypes(AccommodationTypeID),

    constraint FK_Accommodations_Cities
        foreign key (CityID) references stay.Cities(CityID),

    constraint FK_Accommodations_Districts
        foreign key (DistrictID) references stay.Districts(DistrictID),

    constraint CK_Accommodations_PricePerNight
        check (PricePerNight >= 0),

    constraint CK_Accommodations_Rating
        check (Rating >= 0 and Rating <= 5),

    constraint CK_Accommodations_ReviewCount
        check (ReviewCount >= 0),

    constraint CK_Accommodations_MaxPeople
        check (MaxPeople > 0),

    constraint CK_Accommodations_Latitude
        check (Latitude is null or (Latitude >= -90 and Latitude <= 90)),

    constraint CK_Accommodations_Longitude
        check (Longitude is null or (Longitude >= -180 and Longitude <= 180))
)
go

/* ---------------------------------------------------------
   AccommodationImages
--------------------------------------------------------- */
create table stay.AccommodationImages
(
    ImageID int identity(1,1) not null,
    AccommodationID int not null,
    ImageURL nvarchar(500) not null,
    ImageCaption nvarchar(255) null,
    DisplayOrder int not null default 1,
    IsMainImage bit not null default 0,
    CreatedAt datetime2 not null default sysdatetime(),

    constraint PK_AccommodationImages primary key (ImageID),

    constraint FK_AccommodationImages_Accommodations
        foreign key (AccommodationID) references stay.Accommodations(AccommodationID),

    constraint CK_AccommodationImages_DisplayOrder
        check (DisplayOrder > 0)
)
go

/* ---------------------------------------------------------
   AccommodationAmenities
--------------------------------------------------------- */
create table stay.AccommodationAmenities
(
    AccommodationID int not null,
    AmenityID int not null,
    CreatedAt datetime2 not null default sysdatetime(),

    constraint PK_AccommodationAmenities primary key (AccommodationID, AmenityID),

    constraint FK_AccommodationAmenities_Accommodations
        foreign key (AccommodationID) references stay.Accommodations(AccommodationID),

    constraint FK_AccommodationAmenities_Amenities
        foreign key (AmenityID) references stay.Amenities(AmenityID)
)
go

/* ---------------------------------------------------------
   AccommodationTags
--------------------------------------------------------- */
create table stay.AccommodationTags
(
    AccommodationID int not null,
    TagID int not null,
    CreatedAt datetime2 not null default sysdatetime(),

    constraint PK_AccommodationTags primary key (AccommodationID, TagID),

    constraint FK_AccommodationTags_Accommodations
        foreign key (AccommodationID) references stay.Accommodations(AccommodationID),

    constraint FK_AccommodationTags_Tags
        foreign key (TagID) references stay.Tags(TagID)
)
go

/* ---------------------------------------------------------
   Reviews
   Ghi chú:
   - FK sang Users sẽ thêm ở file user_tables vì Users
     được tạo sau file này
--------------------------------------------------------- */
create table stay.Reviews
(
    ReviewID int identity(1,1) not null,
    AccommodationID int not null,
    UserID int null,
    ReviewerName nvarchar(100) null,
    Rating decimal(3,2) not null,
    ReviewTitle nvarchar(200) null,
    ReviewText nvarchar(1000) null,
    ReviewDate date not null default cast(getdate() as date),
    IsApproved bit not null default 1,
    CreatedAt datetime2 not null default sysdatetime(),

    constraint PK_Reviews primary key (ReviewID),

    constraint FK_Reviews_Accommodations
        foreign key (AccommodationID) references stay.Accommodations(AccommodationID),

    constraint CK_Reviews_Rating
        check (Rating >= 0 and Rating <= 5)
)
go