use SmartStayDB
go

declare @CityName nvarchar(100) = N'Đà Lạt'
declare @BudgetMax decimal(12,2) = 800000
declare @TypeName nvarchar(100) = N'Homestay'
declare @NeedAmenity1 nvarchar(100) = N'WiFi'
declare @NeedAmenity2 nvarchar(100) = N'Parking'

with AmenityMatch as
(
    select
        a.AccommodationID,
        count(distinct m.AmenityName) as MatchedAmenityCount
    from stay.Accommodations a
    left join stay.AccommodationAmenities aa on a.AccommodationID = aa.AccommodationID
    left join stay.Amenities m on aa.AmenityID = m.AmenityID
    where m.AmenityName in (@NeedAmenity1, @NeedAmenity2)
    group by a.AccommodationID
)
select
    a.AccommodationID,
    a.AccommodationName,
    c.CityName,
    t.TypeName,
    a.PricePerNight,
    a.Rating,
    a.MaxPeople,

    cast(
        (case when c.CityName = @CityName then 30 else 0 end) +
        (case when a.PricePerNight <= @BudgetMax then 25 else 0 end) +
        (case when t.TypeName = @TypeName then 15 else 0 end) +
        (a.Rating / 5.0 * 20) +
        (isnull(am.MatchedAmenityCount, 0) * 5)
    as decimal(5,2)) as RecommendationScore

from stay.Accommodations a
join stay.Cities c on a.CityID = c.CityID
join stay.AccommodationTypes t on a.AccommodationTypeID = t.AccommodationTypeID
left join AmenityMatch am on a.AccommodationID = am.AccommodationID
where a.IsActive = 1
order by RecommendationScore desc, a.Rating desc
go