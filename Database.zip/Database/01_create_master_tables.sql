/* =========================================================
   File: 01_create_master_tables.sql
   Folder: database/01_master_tables/
   Mục đích:
     Create master tables:
     - Cities 
     - Districts
     - AccommodationTypes
     - Amenities
     - Tags
========================================================= */

use SmartStayDB
go

/* ---------------------------------------------------------
   Cities
--------------------------------------------------------- */
create table stay.Cities
(
    CityID int identity(1,1) not null,
    CityName nvarchar(100) not null,
    Description nvarchar(255) null,
    CenterLatitude decimal(9,6) null,
    CenterLongitude decimal(9,6) null,
    IsActive bit not null default 1,

    constraint PK_Cities primary key (CityID),
    constraint UQ_Cities_CityName unique (CityName)
)
go

/* ---------------------------------------------------------
   Districts
--------------------------------------------------------- */
create table stay.Districts
(
    DistrictID int identity(1,1) not null,
    CityID int not null,
    DistrictName nvarchar(100) not null,
    Description nvarchar(255) null,
    CenterLatitude decimal(9,6) null,
    CenterLongitude decimal(9,6) null,
    IsActive bit not null default 1,

    constraint PK_Districts primary key (DistrictID),
    constraint UQ_Districts_CityID_DistrictName unique (CityID, DistrictName),

    constraint FK_Districts_Cities
        foreign key (CityID) references stay.Cities(CityID)
)
go

/* ---------------------------------------------------------
   AccommodationTypes
--------------------------------------------------------- */
create table stay.AccommodationTypes
(
    AccommodationTypeID int identity(1,1) not null,
    TypeName nvarchar(100) not null,
    Description nvarchar(255) null,
    IsActive bit not null default 1,

    constraint PK_AccommodationTypes primary key (AccommodationTypeID),
    constraint UQ_AccommodationTypes_TypeName unique (TypeName)
)
go

/* ---------------------------------------------------------
   Amenities
--------------------------------------------------------- */
create table stay.Amenities
(
    AmenityID int identity(1,1) not null,
    AmenityName nvarchar(100) not null,
    AmenityIcon nvarchar(255) null,
    Description nvarchar(255) null,
    IsActive bit not null default 1,

    constraint PK_Amenities primary key (AmenityID),
    constraint UQ_Amenities_AmenityName unique (AmenityName)
)
go

/* ---------------------------------------------------------
   Tags
--------------------------------------------------------- */
create table stay.Tags
(
    TagID int identity(1,1) not null,
    TagName nvarchar(100) not null,
    Description nvarchar(255) null,
    IsActive bit not null default 1,

    constraint PK_Tags primary key (TagID),
    constraint UQ_Tags_TagName unique (TagName)
)
go