use SmartStayDB
go

/* Tìm theo city + budget + type */
declare @CityName nvarchar(100) = N'Đà Lạt'
declare @BudgetMax decimal(12,2) = 800000
declare @TypeName nvarchar(100) = N'Homestay'

select
    a.AccommodationID,
    a.AccommodationName,
    c.CityName,
    d.DistrictName,
    t.TypeName,
    a.PricePerNight,
    a.Rating,
    a.MaxPeople
from stay.Accommodations a
join stay.Cities c on a.CityID = c.CityID
left join stay.Districts d on a.DistrictID = d.DistrictID
join stay.AccommodationTypes t on a.AccommodationTypeID = t.AccommodationTypeID
where a.IsActive = 1
  and c.CityName = @CityName
  and a.PricePerNight <= @BudgetMax
  and t.TypeName = @TypeName
order by a.Rating desc, a.PricePerNight asc
go

/* Tìm chỗ ở có đủ 2 tiện nghi: WiFi + Parking */
select
    a.AccommodationID,
    a.AccommodationName
from stay.Accommodations a
join stay.AccommodationAmenities aa on a.AccommodationID = aa.AccommodationID
join stay.Amenities m on aa.AmenityID = m.AmenityID
where m.AmenityName in (N'WiFi', N'Parking')
group by a.AccommodationID, a.AccommodationName
having count(distinct m.AmenityName) = 2
go

/* Sắp xếp theo gần vị trí người dùng */
declare @UserLat decimal(9,6) = 11.940000
declare @UserLng decimal(9,6) = 108.450000

select
    a.AccommodationID,
    a.AccommodationName,
    a.Latitude,
    a.Longitude,
    ((a.Latitude - @UserLat) * (a.Latitude - @UserLat)
     + (a.Longitude - @UserLng) * (a.Longitude - @UserLng)) as DistanceScore
from stay.Accommodations a
where a.Latitude is not null
  and a.Longitude is not null
order by DistanceScore asc
go