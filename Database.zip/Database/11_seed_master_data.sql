use SmartStayDB
go

/* =========================
   Cities
========================= */
if not exists (select 1 from stay.Cities where CityName = N'Đà Lạt')
begin
    insert into stay.Cities
    (
        CityName, Description, CenterLatitude, CenterLongitude, IsActive
    )
    values
    (
        N'Đà Lạt',
        N'Thành phố du lịch khí hậu mát mẻ.',
        11.940419,
        108.458313,
        1
    )
end
go

if not exists (select 1 from stay.Cities where CityName = N'Hồ Chí Minh')
begin
    insert into stay.Cities
    (
        CityName, Description, CenterLatitude, CenterLongitude, IsActive
    )
    values
    (
        N'Hồ Chí Minh',
        N'Thành phố lớn, trung tâm kinh tế và du lịch sôi động.',
        10.776889,
        106.700806,
        1
    )
end
go

if not exists (select 1 from stay.Cities where CityName = N'Đà Nẵng')
begin
    insert into stay.Cities
    (
        CityName, Description, CenterLatitude, CenterLongitude, IsActive
    )
    values
    (
        N'Đà Nẵng',
        N'Thành phố biển nổi tiếng với du lịch và nghỉ dưỡng.',
        16.054407,
        108.202164,
        1
    )
end
go

/* =========================
   Districts
========================= */
if not exists (
    select 1
    from stay.Districts d
    join stay.Cities c on d.CityID = c.CityID
    where c.CityName = N'Đà Lạt' and d.DistrictName = N'Phường 1'
)
begin
    insert into stay.Districts
    (
        CityID, DistrictName, Description, CenterLatitude, CenterLongitude, IsActive
    )
    select
        c.CityID,
        N'Phường 1',
        N'Khu vực trung tâm Đà Lạt.',
        11.941500,
        108.438000,
        1
    from stay.Cities c
    where c.CityName = N'Đà Lạt'
end
go

if not exists (
    select 1
    from stay.Districts d
    join stay.Cities c on d.CityID = c.CityID
    where c.CityName = N'Đà Lạt' and d.DistrictName = N'Phường 10'
)
begin
    insert into stay.Districts
    (
        CityID, DistrictName, Description, CenterLatitude, CenterLongitude, IsActive
    )
    select
        c.CityID,
        N'Phường 10',
        N'Khu vực yên tĩnh, nhiều homestay.',
        11.955000,
        108.463000,
        1
    from stay.Cities c
    where c.CityName = N'Đà Lạt'
end
go

if not exists (
    select 1
    from stay.Districts d
    join stay.Cities c on d.CityID = c.CityID
    where c.CityName = N'Hồ Chí Minh' and d.DistrictName = N'Quận 1'
)
begin
    insert into stay.Districts
    (
        CityID, DistrictName, Description, CenterLatitude, CenterLongitude, IsActive
    )
    select
        c.CityID,
        N'Quận 1',
        N'Khu vực trung tâm TP.HCM.',
        10.775600,
        106.700900,
        1
    from stay.Cities c
    where c.CityName = N'Hồ Chí Minh'
end
go

if not exists (
    select 1
    from stay.Districts d
    join stay.Cities c on d.CityID = c.CityID
    where c.CityName = N'Hồ Chí Minh' and d.DistrictName = N'Quận 7'
)
begin
    insert into stay.Districts
    (
        CityID, DistrictName, Description, CenterLatitude, CenterLongitude, IsActive
    )
    select
        c.CityID,
        N'Quận 7',
        N'Khu vực hiện đại, phù hợp gia đình và căn hộ.',
        10.729900,
        106.721900,
        1
    from stay.Cities c
    where c.CityName = N'Hồ Chí Minh'
end
go

if not exists (
    select 1
    from stay.Districts d
    join stay.Cities c on d.CityID = c.CityID
    where c.CityName = N'Đà Nẵng' and d.DistrictName = N'Hải Châu'
)
begin
    insert into stay.Districts
    (
        CityID, DistrictName, Description, CenterLatitude, CenterLongitude, IsActive
    )
    select
        c.CityID,
        N'Hải Châu',
        N'Khu vực trung tâm Đà Nẵng.',
        16.067800,
        108.220800,
        1
    from stay.Cities c
    where c.CityName = N'Đà Nẵng'
end
go

if not exists (
    select 1
    from stay.Districts d
    join stay.Cities c on d.CityID = c.CityID
    where c.CityName = N'Đà Nẵng' and d.DistrictName = N'Sơn Trà'
)
begin
    insert into stay.Districts
    (
        CityID, DistrictName, Description, CenterLatitude, CenterLongitude, IsActive
    )
    select
        c.CityID,
        N'Sơn Trà',
        N'Khu vực gần biển, phù hợp nghỉ dưỡng.',
        16.110000,
        108.245000,
        1
    from stay.Cities c
    where c.CityName = N'Đà Nẵng'
end
go

/* =========================
   AccommodationTypes
========================= */
if not exists (select 1 from stay.AccommodationTypes where TypeName = N'Hotel')
insert into stay.AccommodationTypes (TypeName, Description, IsActive)
values (N'Hotel', N'Khách sạn tiêu chuẩn.', 1)
go

if not exists (select 1 from stay.AccommodationTypes where TypeName = N'Homestay')
insert into stay.AccommodationTypes (TypeName, Description, IsActive)
values (N'Homestay', N'Chỗ ở phong cách gia đình, ấm cúng.', 1)
go

if not exists (select 1 from stay.AccommodationTypes where TypeName = N'Resort')
insert into stay.AccommodationTypes (TypeName, Description, IsActive)
values (N'Resort', N'Khu nghỉ dưỡng cao cấp.', 1)
go

if not exists (select 1 from stay.AccommodationTypes where TypeName = N'Apartment')
insert into stay.AccommodationTypes (TypeName, Description, IsActive)
values (N'Apartment', N'Căn hộ lưu trú.', 1)
go

if not exists (select 1 from stay.AccommodationTypes where TypeName = N'Hostel')
insert into stay.AccommodationTypes (TypeName, Description, IsActive)
values (N'Hostel', N'Chỗ ở giá rẻ phù hợp sinh viên.', 1)
go

/* =========================
   Amenities
========================= */
if not exists (select 1 from stay.Amenities where AmenityName = N'WiFi')
insert into stay.Amenities (AmenityName, AmenityIcon, Description, IsActive)
values (N'WiFi', N'wifi', N'Có internet không dây.', 1)
go

if not exists (select 1 from stay.Amenities where AmenityName = N'Breakfast')
insert into stay.Amenities (AmenityName, AmenityIcon, Description, IsActive)
values (N'Breakfast', N'utensils', N'Có bữa sáng.', 1)
go

if not exists (select 1 from stay.Amenities where AmenityName = N'Parking')
insert into stay.Amenities (AmenityName, AmenityIcon, Description, IsActive)
values (N'Parking', N'car', N'Có bãi đậu xe.', 1)
go

if not exists (select 1 from stay.Amenities where AmenityName = N'Pool')
insert into stay.Amenities (AmenityName, AmenityIcon, Description, IsActive)
values (N'Pool', N'pool', N'Có hồ bơi.', 1)
go

if not exists (select 1 from stay.Amenities where AmenityName = N'Air Conditioner')
insert into stay.Amenities (AmenityName, AmenityIcon, Description, IsActive)
values (N'Air Conditioner', N'snowflake', N'Có máy lạnh.', 1)
go

if not exists (select 1 from stay.Amenities where AmenityName = N'Kitchen')
insert into stay.Amenities (AmenityName, AmenityIcon, Description, IsActive)
values (N'Kitchen', N'chef-hat', N'Có bếp.', 1)
go

if not exists (select 1 from stay.Amenities where AmenityName = N'24h Reception')
insert into stay.Amenities (AmenityName, AmenityIcon, Description, IsActive)
values (N'24h Reception', N'clock', N'Có lễ tân 24 giờ.', 1)
go

if not exists (select 1 from stay.Amenities where AmenityName = N'Balcony')
insert into stay.Amenities (AmenityName, AmenityIcon, Description, IsActive)
values (N'Balcony', N'building', N'Có ban công.', 1)
go

if not exists (select 1 from stay.Amenities where AmenityName = N'Airport Shuttle')
insert into stay.Amenities (AmenityName, AmenityIcon, Description, IsActive)
values (N'Airport Shuttle', N'plane', N'Có xe đưa đón sân bay.', 1)
go

/* =========================
   Tags
========================= */
if not exists (select 1 from stay.Tags where TagName = N'Near Center')
insert into stay.Tags (TagName, Description, IsActive)
values (N'Near Center', N'Gần trung tâm.', 1)
go

if not exists (select 1 from stay.Tags where TagName = N'Quiet')
insert into stay.Tags (TagName, Description, IsActive)
values (N'Quiet', N'Yên tĩnh.', 1)
go

if not exists (select 1 from stay.Tags where TagName = N'Budget Friendly')
insert into stay.Tags (TagName, Description, IsActive)
values (N'Budget Friendly', N'Phù hợp ngân sách.', 1)
go

if not exists (select 1 from stay.Tags where TagName = N'Family Friendly')
insert into stay.Tags (TagName, Description, IsActive)
values (N'Family Friendly', N'Phù hợp gia đình.', 1)
go

if not exists (select 1 from stay.Tags where TagName = N'Student Friendly')
insert into stay.Tags (TagName, Description, IsActive)
values (N'Student Friendly', N'Phù hợp sinh viên.', 1)
go

if not exists (select 1 from stay.Tags where TagName = N'Luxury')
insert into stay.Tags (TagName, Description, IsActive)
values (N'Luxury', N'Cao cấp.', 1)
go

if not exists (select 1 from stay.Tags where TagName = N'Near Beach')
insert into stay.Tags (TagName, Description, IsActive)
values (N'Near Beach', N'Gần biển.', 1)
go

if not exists (select 1 from stay.Tags where TagName = N'Work Friendly')
insert into stay.Tags (TagName, Description, IsActive)
values (N'Work Friendly', N'Phù hợp làm việc từ xa.', 1)
go