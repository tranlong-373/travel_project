use SmartStayDB
go

/* =========================
   ChatSessions
========================= */
if not exists (
    select 1
    from stay.ChatSessions cs
    join stay.Users u on cs.UserID = u.UserID
    where u.Email = N'long@example.com'
      and cs.SessionTitle = N'Tìm homestay Đà Lạt cho 4 người'
)
begin
    insert into stay.ChatSessions
    (
        UserID, SessionTitle, StartedAt, EndedAt, IsActive
    )
    select
        u.UserID,
        N'Tìm homestay Đà Lạt cho 4 người',
        '2026-03-15 09:25:00',
        '2026-03-15 09:35:00',
        0
    from stay.Users u
    where u.Email = N'long@example.com'
end
go

/* =========================
   ChatMessages
========================= */
if not exists (
    select 1
    from stay.ChatMessages cm
    join stay.ChatSessions cs on cm.ChatSessionID = cs.ChatSessionID
    where cs.SessionTitle = N'Tìm homestay Đà Lạt cho 4 người'
      and cm.MessageText = N'Tìm cho mình homestay ở Đà Lạt dưới 700k cho 4 người.'
)
begin
    insert into stay.ChatMessages
    (
        ChatSessionID, SenderType, MessageText, CreatedAt
    )
    select
        cs.ChatSessionID,
        N'User',
        N'Tìm cho mình homestay ở Đà Lạt dưới 700k cho 4 người.',
        '2026-03-15 09:25:10'
    from stay.ChatSessions cs
    where cs.SessionTitle = N'Tìm homestay Đà Lạt cho 4 người'
end
go

if not exists (
    select 1
    from stay.ChatMessages cm
    join stay.ChatSessions cs on cm.ChatSessionID = cs.ChatSessionID
    where cs.SessionTitle = N'Tìm homestay Đà Lạt cho 4 người'
      and cm.MessageText = N'Mình gợi ý Dalat Green Homestay vì phù hợp ngân sách, yên tĩnh và phù hợp 4 người.'
)
begin
    insert into stay.ChatMessages
    (
        ChatSessionID, SenderType, MessageText, CreatedAt
    )
    select
        cs.ChatSessionID,
        N'Bot',
        N'Mình gợi ý Dalat Green Homestay vì phù hợp ngân sách, yên tĩnh và phù hợp 4 người.',
        '2026-03-15 09:25:25'
    from stay.ChatSessions cs
    where cs.SessionTitle = N'Tìm homestay Đà Lạt cho 4 người'
end
go

/* =========================
   RecommendationLogs
========================= */
if not exists (
    select 1
    from stay.RecommendationLogs rl
    join stay.Users u on rl.UserID = u.UserID
    join stay.Accommodations a on rl.AccommodationID = a.AccommodationID
    where u.Email = N'long@example.com'
      and a.AccommodationName = N'Dalat Green Homestay'
)
begin
    insert into stay.RecommendationLogs
    (
        UserID, AccommodationID, InputSummary,
        RecommendationScore, ReasonText, CreatedAt
    )
    select
        u.UserID,
        a.AccommodationID,
        N'city=Đà Lạt; budget_max=700000; people=4; type=Homestay',
        91.50,
        N'Phù hợp ngân sách, đúng loại homestay, đủ 4 người, yên tĩnh.',
        '2026-03-15 09:25:30'
    from stay.Users u
    join stay.Accommodations a on a.AccommodationName = N'Dalat Green Homestay'
    where u.Email = N'long@example.com'
end
go