use SmartStayDB
go

;with ReviewStats as
(
    select
        r.AccommodationID,
        count(*) as NewReviewCount,
        cast(avg(cast(r.Rating as decimal(10,2))) as decimal(3,2)) as NewRating
    from stay.Reviews r
    where r.IsApproved = 1
    group by r.AccommodationID
)
update a
set
    a.ReviewCount = isnull(rs.NewReviewCount, 0),
    a.Rating = isnull(rs.NewRating, 0)
from stay.Accommodations a
left join ReviewStats rs on a.AccommodationID = rs.AccommodationID
go