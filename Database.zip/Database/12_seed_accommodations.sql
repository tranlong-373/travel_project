use SmartStayDB
go

/* =========================
   Accommodations
========================= */
if not exists (select 1 from stay.Accommodations where AccommodationName = N'Dalat Green Homestay')
begin
    insert into stay.Accommodations
    (
        AccommodationName, AccommodationTypeID, CityID, DistrictID, AddressLine,
        Description, PricePerNight, Rating, ReviewCount, MaxPeople,
        Latitude, Longitude, MainImageURL, PhoneNumber, WebsiteURL,
        CheckInTime, CheckOutTime, IsActive
    )
    select
        N'Dalat Green Homestay',
        t.AccommodationTypeID,
        c.CityID,
        d.DistrictID,
        N'12 Trần Hưng Đạo, Phường 1, Đà Lạt',
        N'Homestay yên tĩnh, phù hợp nhóm bạn và sinh viên.',
        550000,
        0,
        0,
        4,
        11.940400,
        108.458300,
        N'https://example.com/dalat-green-main.jpg',
        N'0901000001',
        N'https://example.com/dalat-green',
        '14:00',
        '12:00',
        1
    from stay.AccommodationTypes t
    join stay.Cities c on c.CityName = N'Đà Lạt'
    join stay.Districts d on d.CityID = c.CityID and d.DistrictName = N'Phường 1'
    where t.TypeName = N'Homestay'
end
go

if not exists (select 1 from stay.Accommodations where AccommodationName = N'Pine Hill Hotel')
begin
    insert into stay.Accommodations
    (
        AccommodationName, AccommodationTypeID, CityID, DistrictID, AddressLine,
        Description, PricePerNight, Rating, ReviewCount, MaxPeople,
        Latitude, Longitude, MainImageURL, PhoneNumber, WebsiteURL,
        CheckInTime, CheckOutTime, IsActive
    )
    select
        N'Pine Hill Hotel',
        t.AccommodationTypeID,
        c.CityID,
        d.DistrictID,
        N'45 Mai Anh Đào, Phường 10, Đà Lạt',
        N'Khách sạn sạch sẽ, gần khu du lịch.',
        780000,
        0,
        0,
        3,
        11.956500,
        108.463800,
        N'https://example.com/pine-hill-main.jpg',
        N'0901000002',
        N'https://example.com/pine-hill',
        '14:00',
        '12:00',
        1
    from stay.AccommodationTypes t
    join stay.Cities c on c.CityName = N'Đà Lạt'
    join stay.Districts d on d.CityID = c.CityID and d.DistrictName = N'Phường 10'
    where t.TypeName = N'Hotel'
end
go

if not exists (select 1 from stay.Accommodations where AccommodationName = N'Saigon Central Hotel')
begin
    insert into stay.Accommodations
    (
        AccommodationName, AccommodationTypeID, CityID, DistrictID, AddressLine,
        Description, PricePerNight, Rating, ReviewCount, MaxPeople,
        Latitude, Longitude, MainImageURL, PhoneNumber, WebsiteURL,
        CheckInTime, CheckOutTime, IsActive
    )
    select
        N'Saigon Central Hotel',
        t.AccommodationTypeID,
        c.CityID,
        d.DistrictID,
        N'25 Nguyễn Huệ, Quận 1, TP.HCM',
        N'Khách sạn gần trung tâm, thuận tiện đi lại.',
        980000,
        0,
        0,
        2,
        10.776900,
        106.700900,
        N'https://example.com/saigon-central-main.jpg',
        N'0901000003',
        N'https://example.com/saigon-central',
        '14:00',
        '12:00',
        1
    from stay.AccommodationTypes t
    join stay.Cities c on c.CityName = N'Hồ Chí Minh'
    join stay.Districts d on d.CityID = c.CityID and d.DistrictName = N'Quận 1'
    where t.TypeName = N'Hotel'
end
go

if not exists (select 1 from stay.Accommodations where AccommodationName = N'Riverside Apartment')
begin
    insert into stay.Accommodations
    (
        AccommodationName, AccommodationTypeID, CityID, DistrictID, AddressLine,
        Description, PricePerNight, Rating, ReviewCount, MaxPeople,
        Latitude, Longitude, MainImageURL, PhoneNumber, WebsiteURL,
        CheckInTime, CheckOutTime, IsActive
    )
    select
        N'Riverside Apartment',
        t.AccommodationTypeID,
        c.CityID,
        d.DistrictID,
        N'88 Nguyễn Lương Bằng, Quận 7, TP.HCM',
        N'Căn hộ đầy đủ tiện nghi, phù hợp gia đình.',
        1200000,
        0,
        0,
        5,
        10.728800,
        106.721500,
        N'https://example.com/riverside-apartment-main.jpg',
        N'0901000004',
        N'https://example.com/riverside-apartment',
        '14:00',
        '12:00',
        1
    from stay.AccommodationTypes t
    join stay.Cities c on c.CityName = N'Hồ Chí Minh'
    join stay.Districts d on d.CityID = c.CityID and d.DistrictName = N'Quận 7'
    where t.TypeName = N'Apartment'
end
go

if not exists (select 1 from stay.Accommodations where AccommodationName = N'Danang Blue Resort')
begin
    insert into stay.Accommodations
    (
        AccommodationName, AccommodationTypeID, CityID, DistrictID, AddressLine,
        Description, PricePerNight, Rating, ReviewCount, MaxPeople,
        Latitude, Longitude, MainImageURL, PhoneNumber, WebsiteURL,
        CheckInTime, CheckOutTime, IsActive
    )
    select
        N'Danang Blue Resort',
        t.AccommodationTypeID,
        c.CityID,
        d.DistrictID,
        N'99 Võ Nguyên Giáp, Hải Châu, Đà Nẵng',
        N'Resort gần biển, phù hợp nghỉ dưỡng.',
        1800000,
        0,
        0,
        5,
        16.067800,
        108.245100,
        N'https://example.com/danang-blue-main.jpg',
        N'0901000005',
        N'https://example.com/danang-blue',
        '15:00',
        '12:00',
        1
    from stay.AccommodationTypes t
    join stay.Cities c on c.CityName = N'Đà Nẵng'
    join stay.Districts d on d.CityID = c.CityID and d.DistrictName = N'Hải Châu'
    where t.TypeName = N'Resort'
end
go

if not exists (select 1 from stay.Accommodations where AccommodationName = N'Sea View Hostel')
begin
    insert into stay.Accommodations
    (
        AccommodationName, AccommodationTypeID, CityID, DistrictID, AddressLine,
        Description, PricePerNight, Rating, ReviewCount, MaxPeople,
        Latitude, Longitude, MainImageURL, PhoneNumber, WebsiteURL,
        CheckInTime, CheckOutTime, IsActive
    )
    select
        N'Sea View Hostel',
        t.AccommodationTypeID,
        c.CityID,
        d.DistrictID,
        N'10 Hồ Nghinh, Sơn Trà, Đà Nẵng',
        N'Hostel giá tốt, gần biển, phù hợp sinh viên.',
        320000,
        0,
        0,
        2,
        16.076500,
        108.244800,
        N'https://example.com/sea-view-hostel-main.jpg',
        N'0901000006',
        N'https://example.com/sea-view-hostel',
        '14:00',
        '11:00',
        1
    from stay.AccommodationTypes t
    join stay.Cities c on c.CityName = N'Đà Nẵng'
    join stay.Districts d on d.CityID = c.CityID and d.DistrictName = N'Sơn Trà'
    where t.TypeName = N'Hostel'
end
go

/* =========================
   AccommodationImages
========================= */
if not exists (
    select 1
    from stay.AccommodationImages ai
    join stay.Accommodations a on ai.AccommodationID = a.AccommodationID
    where a.AccommodationName = N'Dalat Green Homestay'
      and ai.ImageURL = N'https://example.com/dalat-green-1.jpg'
)
begin
    insert into stay.AccommodationImages
    (
        AccommodationID, ImageURL, ImageCaption, DisplayOrder, IsMainImage
    )
    select
        a.AccommodationID,
        N'https://example.com/dalat-green-1.jpg',
        N'Phòng ngủ chính',
        1,
        1
    from stay.Accommodations a
    where a.AccommodationName = N'Dalat Green Homestay'
end
go

if not exists (
    select 1
    from stay.AccommodationImages ai
    join stay.Accommodations a on ai.AccommodationID = a.AccommodationID
    where a.AccommodationName = N'Dalat Green Homestay'
      and ai.ImageURL = N'https://example.com/dalat-green-2.jpg'
)
begin
    insert into stay.AccommodationImages
    (
        AccommodationID, ImageURL, ImageCaption, DisplayOrder, IsMainImage
    )
    select
        a.AccommodationID,
        N'https://example.com/dalat-green-2.jpg',
        N'Khu sinh hoạt chung',
        2,
        0
    from stay.Accommodations a
    where a.AccommodationName = N'Dalat Green Homestay'
end
go

/* Thêm 1 ảnh chính cho mỗi accommodation còn lại */
if not exists (
    select 1 from stay.AccommodationImages ai
    join stay.Accommodations a on ai.AccommodationID = a.AccommodationID
    where a.AccommodationName = N'Pine Hill Hotel'
)
begin
    insert into stay.AccommodationImages
    (
        AccommodationID, ImageURL, ImageCaption, DisplayOrder, IsMainImage
    )
    select a.AccommodationID, N'https://example.com/pine-hill-1.jpg', N'Mặt tiền khách sạn', 1, 1
    from stay.Accommodations a
    where a.AccommodationName = N'Pine Hill Hotel'
end
go

if not exists (
    select 1 from stay.AccommodationImages ai
    join stay.Accommodations a on ai.AccommodationID = a.AccommodationID
    where a.AccommodationName = N'Saigon Central Hotel'
)
begin
    insert into stay.AccommodationImages
    (
        AccommodationID, ImageURL, ImageCaption, DisplayOrder, IsMainImage
    )
    select a.AccommodationID, N'https://example.com/saigon-central-1.jpg', N'Sảnh khách sạn', 1, 1
    from stay.Accommodations a
    where a.AccommodationName = N'Saigon Central Hotel'
end
go

if not exists (
    select 1 from stay.AccommodationImages ai
    join stay.Accommodations a on ai.AccommodationID = a.AccommodationID
    where a.AccommodationName = N'Riverside Apartment'
)
begin
    insert into stay.AccommodationImages
    (
        AccommodationID, ImageURL, ImageCaption, DisplayOrder, IsMainImage
    )
    select a.AccommodationID, N'https://example.com/riverside-1.jpg', N'Phòng khách căn hộ', 1, 1
    from stay.Accommodations a
    where a.AccommodationName = N'Riverside Apartment'
end
go

if not exists (
    select 1 from stay.AccommodationImages ai
    join stay.Accommodations a on ai.AccommodationID = a.AccommodationID
    where a.AccommodationName = N'Danang Blue Resort'
)
begin
    insert into stay.AccommodationImages
    (
        AccommodationID, ImageURL, ImageCaption, DisplayOrder, IsMainImage
    )
    select a.AccommodationID, N'https://example.com/danang-blue-1.jpg', N'Khu nghỉ dưỡng', 1, 1
    from stay.Accommodations a
    where a.AccommodationName = N'Danang Blue Resort'
end
go

if not exists (
    select 1 from stay.AccommodationImages ai
    join stay.Accommodations a on ai.AccommodationID = a.AccommodationID
    where a.AccommodationName = N'Sea View Hostel'
)
begin
    insert into stay.AccommodationImages
    (
        AccommodationID, ImageURL, ImageCaption, DisplayOrder, IsMainImage
    )
    select a.AccommodationID, N'https://example.com/sea-view-1.jpg', N'Phòng dorm', 1, 1
    from stay.Accommodations a
    where a.AccommodationName = N'Sea View Hostel'
end
go

/* =========================
   AccommodationAmenities
========================= */
if not exists (
    select 1
    from stay.AccommodationAmenities aa
    join stay.Accommodations a on aa.AccommodationID = a.AccommodationID
    join stay.Amenities m on aa.AmenityID = m.AmenityID
    where a.AccommodationName = N'Dalat Green Homestay'
      and m.AmenityName = N'WiFi'
)
begin
    insert into stay.AccommodationAmenities (AccommodationID, AmenityID)
    select a.AccommodationID, m.AmenityID
    from stay.Accommodations a
    join stay.Amenities m on m.AmenityName = N'WiFi'
    where a.AccommodationName = N'Dalat Green Homestay'
end
go

if not exists (
    select 1
    from stay.AccommodationAmenities aa
    join stay.Accommodations a on aa.AccommodationID = a.AccommodationID
    join stay.Amenities m on aa.AmenityID = m.AmenityID
    where a.AccommodationName = N'Dalat Green Homestay'
      and m.AmenityName = N'Parking'
)
begin
    insert into stay.AccommodationAmenities (AccommodationID, AmenityID)
    select a.AccommodationID, m.AmenityID
    from stay.Accommodations a
    join stay.Amenities m on m.AmenityName = N'Parking'
    where a.AccommodationName = N'Dalat Green Homestay'
end
go

if not exists (
    select 1
    from stay.AccommodationAmenities aa
    join stay.Accommodations a on aa.AccommodationID = a.AccommodationID
    join stay.Amenities m on aa.AmenityID = m.AmenityID
    where a.AccommodationName = N'Pine Hill Hotel'
      and m.AmenityName = N'Air Conditioner'
)
begin
    insert into stay.AccommodationAmenities (AccommodationID, AmenityID)
    select a.AccommodationID, m.AmenityID
    from stay.Accommodations a
    join stay.Amenities m on m.AmenityName = N'Air Conditioner'
    where a.AccommodationName = N'Pine Hill Hotel'
end
go

if not exists (
    select 1
    from stay.AccommodationAmenities aa
    join stay.Accommodations a on aa.AccommodationID = a.AccommodationID
    join stay.Amenities m on aa.AmenityID = m.AmenityID
    where a.AccommodationName = N'Saigon Central Hotel'
      and m.AmenityName = N'24h Reception'
)
begin
    insert into stay.AccommodationAmenities (AccommodationID, AmenityID)
    select a.AccommodationID, m.AmenityID
    from stay.Accommodations a
    join stay.Amenities m on m.AmenityName = N'24h Reception'
    where a.AccommodationName = N'Saigon Central Hotel'
end
go

if not exists (
    select 1
    from stay.AccommodationAmenities aa
    join stay.Accommodations a on aa.AccommodationID = a.AccommodationID
    join stay.Amenities m on aa.AmenityID = m.AmenityID
    where a.AccommodationName = N'Riverside Apartment'
      and m.AmenityName = N'Kitchen'
)
begin
    insert into stay.AccommodationAmenities (AccommodationID, AmenityID)
    select a.AccommodationID, m.AmenityID
    from stay.Accommodations a
    join stay.Amenities m on m.AmenityName = N'Kitchen'
    where a.AccommodationName = N'Riverside Apartment'
end
go

if not exists (
    select 1
    from stay.AccommodationAmenities aa
    join stay.Accommodations a on aa.AccommodationID = a.AccommodationID
    join stay.Amenities m on aa.AmenityID = m.AmenityID
    where a.AccommodationName = N'Danang Blue Resort'
      and m.AmenityName = N'Pool'
)
begin
    insert into stay.AccommodationAmenities (AccommodationID, AmenityID)
    select a.AccommodationID, m.AmenityID
    from stay.Accommodations a
    join stay.Amenities m on m.AmenityName = N'Pool'
    where a.AccommodationName = N'Danang Blue Resort'
end
go

if not exists (
    select 1
    from stay.AccommodationAmenities aa
    join stay.Accommodations a on aa.AccommodationID = a.AccommodationID
    join stay.Amenities m on aa.AmenityID = m.AmenityID
    where a.AccommodationName = N'Sea View Hostel'
      and m.AmenityName = N'WiFi'
)
begin
    insert into stay.AccommodationAmenities (AccommodationID, AmenityID)
    select a.AccommodationID, m.AmenityID
    from stay.Accommodations a
    join stay.Amenities m on m.AmenityName = N'WiFi'
    where a.AccommodationName = N'Sea View Hostel'
end
go

/* =========================
   AccommodationTags
========================= */
if not exists (
    select 1
    from stay.AccommodationTags atg
    join stay.Accommodations a on atg.AccommodationID = a.AccommodationID
    join stay.Tags t on atg.TagID = t.TagID
    where a.AccommodationName = N'Dalat Green Homestay'
      and t.TagName = N'Quiet'
)
begin
    insert into stay.AccommodationTags (AccommodationID, TagID)
    select a.AccommodationID, t.TagID
    from stay.Accommodations a
    join stay.Tags t on t.TagName = N'Quiet'
    where a.AccommodationName = N'Dalat Green Homestay'
end
go

if not exists (
    select 1
    from stay.AccommodationTags atg
    join stay.Accommodations a on atg.AccommodationID = a.AccommodationID
    join stay.Tags t on atg.TagID = t.TagID
    where a.AccommodationName = N'Saigon Central Hotel'
      and t.TagName = N'Near Center'
)
begin
    insert into stay.AccommodationTags (AccommodationID, TagID)
    select a.AccommodationID, t.TagID
    from stay.Accommodations a
    join stay.Tags t on t.TagName = N'Near Center'
    where a.AccommodationName = N'Saigon Central Hotel'
end
go

if not exists (
    select 1
    from stay.AccommodationTags atg
    join stay.Accommodations a on atg.AccommodationID = a.AccommodationID
    join stay.Tags t on atg.TagID = t.TagID
    where a.AccommodationName = N'Riverside Apartment'
      and t.TagName = N'Family Friendly'
)
begin
    insert into stay.AccommodationTags (AccommodationID, TagID)
    select a.AccommodationID, t.TagID
    from stay.Accommodations a
    join stay.Tags t on t.TagName = N'Family Friendly'
    where a.AccommodationName = N'Riverside Apartment'
end
go

if not exists (
    select 1
    from stay.AccommodationTags atg
    join stay.Accommodations a on atg.AccommodationID = a.AccommodationID
    join stay.Tags t on atg.TagID = t.TagID
    where a.AccommodationName = N'Danang Blue Resort'
      and t.TagName = N'Luxury'
)
begin
    insert into stay.AccommodationTags (AccommodationID, TagID)
    select a.AccommodationID, t.TagID
    from stay.Accommodations a
    join stay.Tags t on t.TagName = N'Luxury'
    where a.AccommodationName = N'Danang Blue Resort'
end
go

if not exists (
    select 1
    from stay.AccommodationTags atg
    join stay.Accommodations a on atg.AccommodationID = a.AccommodationID
    join stay.Tags t on atg.TagID = t.TagID
    where a.AccommodationName = N'Sea View Hostel'
      and t.TagName = N'Student Friendly'
)
begin
    insert into stay.AccommodationTags (AccommodationID, TagID)
    select a.AccommodationID, t.TagID
    from stay.Accommodations a
    join stay.Tags t on t.TagName = N'Student Friendly'
    where a.AccommodationName = N'Sea View Hostel'
end
go