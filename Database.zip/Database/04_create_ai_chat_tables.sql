/* =========================================================
   File: 01_create_ai_chat_tables.sql
   Folder: database/04_ai_chat_tables/
   Mục đích:
     Create AI / chat tables:
     - ChatSessions
     - ChatMessages
     - RecommendationLogs
========================================================= */

use SmartStayDB
go

/* ---------------------------------------------------------
   ChatSessions
--------------------------------------------------------- */
create table stay.ChatSessions
(
    ChatSessionID int identity(1,1) not null,
    UserID int null,
    SessionTitle nvarchar(200) null,
    StartedAt datetime2 not null default sysdatetime(),
    EndedAt datetime2 null,
    IsActive bit not null default 1,

    constraint PK_ChatSessions primary key (ChatSessionID),

    constraint FK_ChatSessions_Users
        foreign key (UserID) references stay.Users(UserID)
)
go

/* ---------------------------------------------------------
   ChatMessages
--------------------------------------------------------- */
create table stay.ChatMessages
(
    MessageID int identity(1,1) not null,
    ChatSessionID int not null,
    SenderType nvarchar(20) not null,
    MessageText nvarchar(2000) not null,
    CreatedAt datetime2 not null default sysdatetime(),

    constraint PK_ChatMessages primary key (MessageID),

    constraint FK_ChatMessages_ChatSessions
        foreign key (ChatSessionID) references stay.ChatSessions(ChatSessionID),

    constraint CK_ChatMessages_SenderType
        check (SenderType in ('User', 'Bot'))
)
go

/* ---------------------------------------------------------
   RecommendationLogs
--------------------------------------------------------- */
create table stay.RecommendationLogs
(
    RecommendationLogID int identity(1,1) not null,
    UserID int null,
    AccommodationID int not null,
    InputSummary nvarchar(1000) null,
    RecommendationScore decimal(5,2) not null,
    ReasonText nvarchar(1000) null,
    CreatedAt datetime2 not null default sysdatetime(),

    constraint PK_RecommendationLogs primary key (RecommendationLogID),

    constraint FK_RecommendationLogs_Users
        foreign key (UserID) references stay.Users(UserID),

    constraint FK_RecommendationLogs_Accommodations
        foreign key (AccommodationID) references stay.Accommodations(AccommodationID),

    constraint CK_RecommendationLogs_RecommendationScore
        check (RecommendationScore >= 0 and RecommendationScore <= 100)
)
go