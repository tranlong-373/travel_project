use SmartStayDB
go

/* =====================================================
   TEMPLATE THÊM 1 CHỖ Ở MỚI
   Sửa các giá trị bên dưới rồi chạy
===================================================== */

/* 1. Thêm accommodation */
if not exists (select 1 from stay.Accommodations where AccommodationName = N'New Demo Stay')
begin
    insert into stay.Accommodations
    (
        AccommodationName, AccommodationTypeID, CityID, DistrictID, AddressLine,
        Description, PricePerNight, Rating, ReviewCount, MaxPeople,
        Latitude, Longitude, MainImageURL, PhoneNumber, WebsiteURL,
        CheckInTime, CheckOutTime, IsActive
    )
    select
        N'New Demo Stay',
        t.AccommodationTypeID,
        c.CityID,
        d.DistrictID,
        N'Địa chỉ mới',
        N'Mô tả mới',
        650000,
        0,
        0,
        3,
        11.950000,
        108.460000,
        N'https://example.com/new-demo.jpg',
        N'0909999999',
        N'https://example.com/new-demo',
        '14:00',
        '12:00',
        1
    from stay.AccommodationTypes t
    join stay.Cities c on c.CityName = N'Đà Lạt'
    join stay.Districts d on d.CityID = c.CityID and d.DistrictName = N'Phường 1'
    where t.TypeName = N'Homestay'
end
go

/* 2. Thêm ảnh */
if not exists (
    select 1
    from stay.AccommodationImages ai
    join stay.Accommodations a on ai.AccommodationID = a.AccommodationID
    where a.AccommodationName = N'New Demo Stay'
      and ai.ImageURL = N'https://example.com/new-demo-1.jpg'
)
begin
    insert into stay.AccommodationImages
    (
        AccommodationID, ImageURL, ImageCaption, DisplayOrder, IsMainImage
    )
    select
        a.AccommodationID,
        N'https://example.com/new-demo-1.jpg',
        N'Ảnh chính',
        1,
        1
    from stay.Accommodations a
    where a.AccommodationName = N'New Demo Stay'
end
go

/* 3. Gán amenity */
if not exists (
    select 1
    from stay.AccommodationAmenities aa
    join stay.Accommodations a on aa.AccommodationID = a.AccommodationID
    join stay.Amenities m on aa.AmenityID = m.AmenityID
    where a.AccommodationName = N'New Demo Stay'
      and m.AmenityName = N'WiFi'
)
begin
    insert into stay.AccommodationAmenities (AccommodationID, AmenityID)
    select a.AccommodationID, m.AmenityID
    from stay.Accommodations a
    join stay.Amenities m on m.AmenityName = N'WiFi'
    where a.AccommodationName = N'New Demo Stay'
end
go

/* 4. Gán tag */
if not exists (
    select 1
    from stay.AccommodationTags atg
    join stay.Accommodations a on atg.AccommodationID = a.AccommodationID
    join stay.Tags t on atg.TagID = t.TagID
    where a.AccommodationName = N'New Demo Stay'
      and t.TagName = N'Quiet'
)
begin
    insert into stay.AccommodationTags (AccommodationID, TagID)
    select a.AccommodationID, t.TagID
    from stay.Accommodations a
    join stay.Tags t on t.TagName = N'Quiet'
    where a.AccommodationName = N'New Demo Stay'
end
go