use SmartStayDB
go

declare @AccommodationID int = 1

/* Thông tin chính */
select
    a.AccommodationID,
    a.AccommodationName,
    a.AddressLine,
    a.Description,
    a.PricePerNight,
    a.Rating,
    a.ReviewCount,
    a.MaxPeople,
    a.Latitude,
    a.Longitude,
    c.CityName,
    d.DistrictName,
    t.TypeName
from stay.Accommodations a
join stay.Cities c on a.CityID = c.CityID
left join stay.Districts d on a.DistrictID = d.DistrictID
join stay.AccommodationTypes t on a.AccommodationTypeID = t.AccommodationTypeID
where a.AccommodationID = @AccommodationID
go

/* Ảnh */
select
    ai.ImageID,
    ai.ImageURL,
    ai.ImageCaption,
    ai.DisplayOrder,
    ai.IsMainImage
from stay.AccommodationImages ai
where ai.AccommodationID = @AccommodationID
order by ai.DisplayOrder asc
go

/* Tiện nghi */
select
    m.AmenityName
from stay.AccommodationAmenities aa
join stay.Amenities m on aa.AmenityID = m.AmenityID
where aa.AccommodationID = @AccommodationID
order by m.AmenityName
go

/* Tags */
select
    t.TagName
from stay.AccommodationTags atg
join stay.Tags t on atg.TagID = t.TagID
where atg.AccommodationID = @AccommodationID
order by t.TagName
go

/* Reviews */
select
    r.ReviewID,
    r.ReviewerName,
    r.Rating,
    r.ReviewTitle,
    r.ReviewText,
    r.ReviewDate
from stay.Reviews r
where r.AccommodationID = @AccommodationID
  and r.IsApproved = 1
order by r.ReviewDate desc
go