/* =========================================================
   File: 01_create_database.sql
   Folder: database/00_init/
   Mục đích:
     Create database
   SQL Server / SSMS
========================================================= */

if db_id('SmartStayDB') is not null
begin
    alter database SmartStayDB set single_user with rollback immediate;
    drop database SmartStayDB;
end
go

create database SmartStayDB
go

use SmartStayDB
go

/* ---------------------------------------------------------
   Tạo schema riêng cho project
   - stay : schema riêng cho hệ thống lưu trú
--------------------------------------------------------- */
if not exists (
    select 1
    from sys.schemas
    where name = 'stay'
)
begin
    exec('create schema stay');
end
go
