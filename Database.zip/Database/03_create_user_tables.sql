/* =========================================================
   File: 01_create_user_tables.sql
   Folder: database/03_user_tables/
   Mục đích:
     Create user tables:
     - Users
     - Favorites
     - SearchHistories
     Sau đó bổ sung FK từ Reviews sang Users
========================================================= */

use SmartStayDB
go

/* ---------------------------------------------------------
   Users
--------------------------------------------------------- */
create table stay.Users
(
    UserID int identity(1,1) not null,
    FullName nvarchar(100) not null,
    Email nvarchar(100) not null,
    PasswordHash nvarchar(255) not null,
    PhoneNumber nvarchar(20) null,
    AvatarURL nvarchar(500) null,
    Role nvarchar(20) not null default 'User',
    IsActive bit not null default 1,
    CreatedAt datetime2 not null default sysdatetime(),
    UpdatedAt datetime2 null,

    constraint PK_Users primary key (UserID),
    constraint UQ_Users_Email unique (Email),

    constraint CK_Users_Role
        check (Role in ('User', 'Admin'))
)
go

/* ---------------------------------------------------------
   Favorites
--------------------------------------------------------- */
create table stay.Favorites
(
    FavoriteID int identity(1,1) not null,
    UserID int not null,
    AccommodationID int not null,
    CreatedAt datetime2 not null default sysdatetime(),

    constraint PK_Favorites primary key (FavoriteID),
    constraint UQ_Favorites_UserID_AccommodationID unique (UserID, AccommodationID),

    constraint FK_Favorites_Users
        foreign key (UserID) references stay.Users(UserID),

    constraint FK_Favorites_Accommodations
        foreign key (AccommodationID) references stay.Accommodations(AccommodationID)
)
go

/* ---------------------------------------------------------
   SearchHistories
--------------------------------------------------------- */
create table stay.SearchHistories
(
    SearchHistoryID int identity(1,1) not null,
    UserID int null,
    CityID int null,
    DistrictID int null,
    AccommodationTypeID int null,
    BudgetMin decimal(12,2) null,
    BudgetMax decimal(12,2) null,
    NumberOfPeople int null,
    PriorityText nvarchar(100) null,
    SearchKeyword nvarchar(255) null,
    SearchTime datetime2 not null default sysdatetime(),

    constraint PK_SearchHistories primary key (SearchHistoryID),

    constraint FK_SearchHistories_Users
        foreign key (UserID) references stay.Users(UserID),

    constraint FK_SearchHistories_Cities
        foreign key (CityID) references stay.Cities(CityID),

    constraint FK_SearchHistories_Districts
        foreign key (DistrictID) references stay.Districts(DistrictID),

    constraint FK_SearchHistories_AccommodationTypes
        foreign key (AccommodationTypeID) references stay.AccommodationTypes(AccommodationTypeID),

    constraint CK_SearchHistories_BudgetMin
        check (BudgetMin is null or BudgetMin >= 0),

    constraint CK_SearchHistories_BudgetMax
        check (BudgetMax is null or BudgetMax >= 0),

    constraint CK_SearchHistories_BudgetRange
        check (BudgetMin is null or BudgetMax is null or BudgetMin <= BudgetMax),

    constraint CK_SearchHistories_NumberOfPeople
        check (NumberOfPeople is null or NumberOfPeople > 0)
)
go

/* ---------------------------------------------------------
   Add FK from Reviews to Users
--------------------------------------------------------- */
alter table stay.Reviews
add constraint FK_Reviews_Users
foreign key (UserID) references stay.Users(UserID)
go