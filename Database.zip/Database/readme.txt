DATABASE README
===============

1. NHÓM FILE CREATE
- 00_create_database.sql
- 01_create_master_tables.sql
- 02_create_core_table.sql
- 03_create_user_tables.sql
- 04_create_ai_chat_tables.sql

2. NHÓM FILE SEED
- 11_seed_master_data.sql
- 12_seed_accommodations.sql
- 13_seed_user_data.sql
- 14_seed_ai_chat_data.sql

3. NHÓM FILE QUERY
- 21_query_search.sql
- 22_query_detail.sql
- 23_query_recommendation.sql

4. NHÓM FILE MAINTENANCE
- 31_insert_more_data_template.sql
- 41_refresh_accommodation_rating.sql

5. THỨ TỰ CHẠY
00 -> 01 -> 02 -> 03 -> 04 -> 11 -> 12 -> 13 -> 14 -> 41

6. QUERY TEST
Chạy:
- 21_query_search.sql
- 22_query_detail.sql
- 23_query_recommendation.sql

7. THÊM DỮ LIỆU MỚI
Dùng:
- 31_insert_more_data_template.sql

8. CẬP NHẬT LẠI RATING
Dùng:
- 41_refresh_accommodation_rating.sql