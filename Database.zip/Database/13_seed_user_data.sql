use SmartStayDB
go

/* =========================
   Users
========================= */
if not exists (select 1 from stay.Users where Email = N'long@example.com')
insert into stay.Users
(
    FullName, Email, PasswordHash, PhoneNumber, AvatarURL, Role, IsActive
)
values
(
    N'Trần Minh Long',
    N'long@example.com',
    N'hash_long_123',
    N'0909000001',
    N'https://example.com/avatar-long.jpg',
    N'User',
    1
)
go

if not exists (select 1 from stay.Users where Email = N'lan@example.com')
insert into stay.Users
(
    FullName, Email, PasswordHash, PhoneNumber, AvatarURL, Role, IsActive
)
values
(
    N'Nguyễn Thu Lan',
    N'lan@example.com',
    N'hash_lan_123',
    N'0909000002',
    N'https://example.com/avatar-lan.jpg',
    N'User',
    1
)
go

if not exists (select 1 from stay.Users where Email = N'huy@example.com')
insert into stay.Users
(
    FullName, Email, PasswordHash, PhoneNumber, AvatarURL, Role, IsActive
)
values
(
    N'Lê Quang Huy',
    N'huy@example.com',
    N'hash_huy_123',
    N'0909000003',
    N'https://example.com/avatar-huy.jpg',
    N'User',
    1
)
go

if not exists (select 1 from stay.Users where Email = N'admin@example.com')
insert into stay.Users
(
    FullName, Email, PasswordHash, PhoneNumber, AvatarURL, Role, IsActive
)
values
(
    N'Admin Demo',
    N'admin@example.com',
    N'hash_admin_123',
    N'0909000005',
    N'https://example.com/avatar-admin.jpg',
    N'Admin',
    1
)
go

/* =========================
   Reviews
========================= */
if not exists (
    select 1
    from stay.Reviews r
    join stay.Accommodations a on r.AccommodationID = a.AccommodationID
    join stay.Users u on r.UserID = u.UserID
    where a.AccommodationName = N'Dalat Green Homestay'
      and u.Email = N'lan@example.com'
      and r.ReviewTitle = N'Không gian dễ chịu'
)
begin
    insert into stay.Reviews
    (
        AccommodationID, UserID, ReviewerName, Rating, ReviewTitle,
        ReviewText, ReviewDate, IsApproved
    )
    select
        a.AccommodationID,
        u.UserID,
        u.FullName,
        4.60,
        N'Không gian dễ chịu',
        N'Homestay sạch sẽ, yên tĩnh, phù hợp nhóm bạn.',
        '2026-03-10',
        1
    from stay.Accommodations a
    join stay.Users u on u.Email = N'lan@example.com'
    where a.AccommodationName = N'Dalat Green Homestay'
end
go

if not exists (
    select 1
    from stay.Reviews r
    join stay.Accommodations a on r.AccommodationID = a.AccommodationID
    join stay.Users u on r.UserID = u.UserID
    where a.AccommodationName = N'Saigon Central Hotel'
      and u.Email = N'long@example.com'
      and r.ReviewTitle = N'Rất tiện di chuyển'
)
begin
    insert into stay.Reviews
    (
        AccommodationID, UserID, ReviewerName, Rating, ReviewTitle,
        ReviewText, ReviewDate, IsApproved
    )
    select
        a.AccommodationID,
        u.UserID,
        u.FullName,
        4.50,
        N'Rất tiện di chuyển',
        N'Ngay khu trung tâm, phù hợp đi công tác ngắn ngày.',
        '2026-03-08',
        1
    from stay.Accommodations a
    join stay.Users u on u.Email = N'long@example.com'
    where a.AccommodationName = N'Saigon Central Hotel'
end
go

if not exists (
    select 1
    from stay.Reviews r
    join stay.Accommodations a on r.AccommodationID = a.AccommodationID
    join stay.Users u on r.UserID = u.UserID
    where a.AccommodationName = N'Danang Blue Resort'
      and u.Email = N'huy@example.com'
      and r.ReviewTitle = N'Rất đáng tiền'
)
begin
    insert into stay.Reviews
    (
        AccommodationID, UserID, ReviewerName, Rating, ReviewTitle,
        ReviewText, ReviewDate, IsApproved
    )
    select
        a.AccommodationID,
        u.UserID,
        u.FullName,
        4.80,
        N'Rất đáng tiền',
        N'Resort đẹp, gần biển, dịch vụ tốt.',
        '2026-03-07',
        1
    from stay.Accommodations a
    join stay.Users u on u.Email = N'huy@example.com'
    where a.AccommodationName = N'Danang Blue Resort'
end
go

/* =========================
   Favorites
========================= */
if not exists (
    select 1
    from stay.Favorites f
    join stay.Users u on f.UserID = u.UserID
    join stay.Accommodations a on f.AccommodationID = a.AccommodationID
    where u.Email = N'long@example.com'
      and a.AccommodationName = N'Danang Blue Resort'
)
begin
    insert into stay.Favorites (UserID, AccommodationID)
    select u.UserID, a.AccommodationID
    from stay.Users u
    join stay.Accommodations a on a.AccommodationName = N'Danang Blue Resort'
    where u.Email = N'long@example.com'
end
go

if not exists (
    select 1
    from stay.Favorites f
    join stay.Users u on f.UserID = u.UserID
    join stay.Accommodations a on f.AccommodationID = a.AccommodationID
    where u.Email = N'lan@example.com'
      and a.AccommodationName = N'Riverside Apartment'
)
begin
    insert into stay.Favorites (UserID, AccommodationID)
    select u.UserID, a.AccommodationID
    from stay.Users u
    join stay.Accommodations a on a.AccommodationName = N'Riverside Apartment'
    where u.Email = N'lan@example.com'
end
go

/* =========================
   SearchHistories
========================= */
if not exists (
    select 1
    from stay.SearchHistories sh
    join stay.Users u on sh.UserID = u.UserID
    where u.Email = N'long@example.com'
      and sh.SearchKeyword = N'homestay đà lạt 4 người'
)
begin
    insert into stay.SearchHistories
    (
        UserID, CityID, DistrictID, AccommodationTypeID,
        BudgetMin, BudgetMax, NumberOfPeople,
        PriorityText, SearchKeyword, SearchTime
    )
    select
        u.UserID,
        c.CityID,
        d.DistrictID,
        t.AccommodationTypeID,
        300000,
        700000,
        4,
        N'giá rẻ, yên tĩnh',
        N'homestay đà lạt 4 người',
        '2026-03-15 09:30:00'
    from stay.Users u
    join stay.Cities c on c.CityName = N'Đà Lạt'
    join stay.Districts d on d.CityID = c.CityID and d.DistrictName = N'Phường 1'
    join stay.AccommodationTypes t on t.TypeName = N'Homestay'
    where u.Email = N'long@example.com'
end
go